/* 
 * File:   servoClap.h
 * Author: Kevin
 *
 * Created on 25 septembre 2015, 13:42
 */

#ifndef SERVOCLAP_H
#define	SERVOCLAP_H

void initServoClap(void);

void rentrerServoClap(void);

void sortirServoClap(void);


#endif	/* SERVOCLAP_H */

