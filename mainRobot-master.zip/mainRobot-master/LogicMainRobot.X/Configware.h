#ifndef CONFIG_H
#define CONFIG_H


#include <xc.h>

void pllConfig(void);
void canPinAssign(void);


#endif
