#ifndef CONFIG_H
#define CONFIG_H


void pllConfig(void);
void canPinAssign(void);


#endif
