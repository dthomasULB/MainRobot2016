
void addTranslation(translationParamType param);
void addRotation(rotationParamType param);
void stopNow(void);
relativePosType calcSegment(absolutePosType curPos, absolutePosType newPos);